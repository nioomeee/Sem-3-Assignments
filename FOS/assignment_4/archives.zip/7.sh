#  Write a shell script that uncompresses the two file separetely

echo "Uncompressing file1"
gunzip file1.gz

echo "Uncompressing file2"
gunzip file2.gz