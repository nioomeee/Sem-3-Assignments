# Write a shell script that display the disk usage of files and directories on a machine.
echo "disk usage of files on machine" 
du -a