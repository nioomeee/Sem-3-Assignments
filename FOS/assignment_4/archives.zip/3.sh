# Write a shell script that display disk space used by files in the following criteria:
#  • write counts for all files , not just directories
du -ah .
#  • total count
du -sh .
