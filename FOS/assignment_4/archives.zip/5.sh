# Write a shell script that provides information about used ansd unused memory
free -h
