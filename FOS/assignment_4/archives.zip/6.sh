# Write a shell script that compresses the two file separetely
echo "Compressing file1"
gzip file1

echo "Compressing file 2"
gzip file2