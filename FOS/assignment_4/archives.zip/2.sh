# Write a shell script that display full summary of available and used disk space usage of the file 
# system on linux system
df -h --total 